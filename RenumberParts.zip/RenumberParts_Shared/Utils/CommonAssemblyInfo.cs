﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RenumberParts
{
    public class CommonAssemblyInfo
    {
        private static string number = "1.2.0.0";

        public static string Number
        {
            get { return number; }
            set { number = value; }
        }
    }
}
